<html>
  <head>
    <title>reCAPTCHA demo: Explicit render after an onload callback</title>
    <script type="text/javascript">
      var onloadCallback = function() {
        grecaptcha.render('html_element', {
          'sitekey' : '6Lcfx7oUAAAAAG9DKVXfv8hkNBvtMHkNFUWS65Pc'
        });
      };
    </script>
  </head>
  <body>
    <form action="<?php echo 'contact.php'; ?>" method="POST">
      <input type="text" name="name">
      <div id="html_element"></div>
      <br>
      <input type="submit" value="Submit">
    </form>
    <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"
        async defer>
    </script>
  </body>
</html>