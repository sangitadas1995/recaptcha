<?php 

define('SITE_KEY',"6Lcfx7oUAAAAAG9DKVXfv8hkNBvtMHkNFUWS65Pc"); 
define('SECRET_KEY',"6Lcfx7oUAAAAALYcTufHjilY3qPF35NiMcwlA4rd");

?>