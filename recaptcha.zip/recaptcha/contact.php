<?php 
require('constant.php');
if (!empty($_POST)) {
	echo "<pre>"; print_r($_POST);
	if (isset($_POST['g-recaptcha-response'])) {


	    // Verify the reCAPTCHA response 
	    $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.SECRET_KEY.'&response='.$_POST['g-recaptcha-response']); 
	     
	    // Decode json data 
	    $responseData = json_decode($verifyResponse);
	    print_r($responseData); die;

	}

}

?>